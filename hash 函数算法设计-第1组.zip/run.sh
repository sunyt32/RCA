# 生成测试文件（共十个测例）
python test.py
#编译
g++ main.cpp -o RCA
#运行测试
./RCA < input.txt